# Placeholder for OCR logic
def extract_grid(image_path):
    return "GRID extracted"