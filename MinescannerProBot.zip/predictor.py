def analyze_image(image_path):
    # Dummy prediction logic for now
    # Later we integrate real OCR + AI pattern detection
    return "✅ Safe tiles: (1,1), (1,2), (2,3)
❌ Danger tiles: (3,3), (4,1)"